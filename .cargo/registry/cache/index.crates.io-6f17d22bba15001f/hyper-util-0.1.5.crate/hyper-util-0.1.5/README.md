# hyper-util

[![crates.io](https://img.shields.io/crates/v/hyper-util.svg)](https://crates.io/crates/hyper-util)
[![Released API docs](https://docs.rs/hyper-util/badge.svg)](https://docs.rs/hyper-util)
[![MIT licensed](https://img.shields.io/badge/license-MIT-blue.svg)](./LICENSE)

A collection of utilities to do common things with [hyper](https://hyper.rs).

## License

This project is licensed under the [MIT license](./LICENSE).
