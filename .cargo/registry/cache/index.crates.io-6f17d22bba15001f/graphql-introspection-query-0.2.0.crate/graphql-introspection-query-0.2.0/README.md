# graphql-introspection-query

This crate defines structs implementing `serde::Deserialize` that match the shape returned by a spec-compliant GraphQL API presented with the introspection query.
